from homework.求最大公约数.GCD import whileGCD
from homework.求最大公约数.GCD import forGCD
def main():
    a=int(input())
    b=int(input())
    print(whileGCD(a,b))
    print(forGCD(a,b))
main()


